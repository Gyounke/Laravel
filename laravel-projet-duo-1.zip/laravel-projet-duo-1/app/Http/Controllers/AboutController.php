<?php

namespace App\Http\Controllers;

use App\Models\About;
use Illuminate\Http\Request;

class AboutController extends Controller
{
    public function index(){
        $about = About::all();
        return view('tables.abouttable', compact('about'));
    }

    public function destroy($id){
        $about = About::find($id);
        $about->delete();
        return redirect()->back();
    }

    public function edit($lid){
        $about = About::find($lid);
        return view('edit.aboutedit', compact('about'));
    }

    public function update($id, Request $request) {
        $about = About::find($id);
        $about->scores = $request->scores;
        $about->text = $request->text;
        $about->updated_at = now();
        $about->save();
        return redirect()->route("abouts.index");
    }
}
