<?php

namespace App\Http\Controllers;

use App\Models\Discover;
use Illuminate\Http\Request;

class DiscoverController extends Controller
{
    public function index(){
        $discover = Discover::all();
        return view('tables.discovertable', compact('discover'));
    }
    
}
