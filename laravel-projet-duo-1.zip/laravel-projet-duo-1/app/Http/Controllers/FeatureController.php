<?php

namespace App\Http\Controllers;

use App\Models\Feature;
use Illuminate\Http\Request;

class FeatureController extends Controller
{
    public function index(){
        $feature = Feature::all();
        return view('tables.featuretable', compact('feature'));
    }

    public function destroy($id){
        $feature = Feature::find($id);
        $feature->delete();
        return redirect()->back();
    }

    public function edit($lid){
        $feature = Feature::find($lid);
        return view('edit.featureedit', compact('feature'));
    }

    public function update($id, Request $request) {
        $feature = Feature::find($id);
        $feature->number = $request->number;
        $feature->numberbg = $request->numberbg;
        $feature->icon = $request->icon;
        $feature->title = $request->title;
        $feature->text = $request->text;
        $feature->updated_at = now();
        $feature->save();
        return redirect()->route("features.index");
    }


}


