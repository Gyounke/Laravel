<?php

namespace App\Http\Controllers;

use App\Models\Navlink;
use Illuminate\Http\Request;

class NavlinkController extends Controller
{
    public function index(){
        $navlink = Navlink::all();
        return view('tables.navlinktable', compact('navlink'));
    }

    public function destroy($id){
        $navlink = Navlink::find($id);
        $navlink->delete();
        return redirect()->back();
    }

    public function edit($lid){
        $navlink = Navlink::find($lid);
        return view('edit.navlinkedit', compact('navlink'));
    }

    public function update($id, Request $request) {
        $navlink = Navlink::find($id);
        $navlink->content = $request->content;
        $navlink->link = $request->link;
        $navlink->updated_at = now();
        $navlink->save();
        return redirect()->route("navlinks.index");
    }
    
}
