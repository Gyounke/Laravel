<?php

namespace App\Http\Controllers;

use App\Models\Portfolio;
use Illuminate\Http\Request;

class PortfolioController extends Controller
{
    public function index(){
        $portfolio = Portfolio::all();
        return view('tables.portfoliotable', compact('portfolio'));
    }

    public function destroy($id){
        $portfolio = Portfolio::find($id);
        $portfolio->delete();
        return redirect()->back();
    }

    public function edit($lid){
        $portfolio = Portfolio::find($lid);
        return view('edit.portfolioedit', compact('portfolio'));
    }

    public function update($id, Request $request) {
        $portfolio = Portfolio::find($id);
        $portfolio->image = $request->image;
        $portfolio->title = $request->title;
        $portfolio->text = $request->text;
        $portfolio->updated_at = now();
        $portfolio->save();
        return redirect()->route("portfolios.index");
    }
}
