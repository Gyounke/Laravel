<?php

namespace App\Http\Controllers;

use App\Models\Service;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function index(){
        $service = Service::all();
        return view('tables.servicetable', compact('service'));
    }

    public function destroy($id){
        $service = Service::find($id);
        $service->delete();
        return redirect()->back();
    }

    public function edit($lid){
        $service = Service::find($lid);
        return view('edit.serviceedit', compact('service'));
    }

    public function update($id, Request $request) {
        $service = Service::find($id);
        $service->iconpath = $request->iconpath;
        $service->title = $request->title;
        $service->text = $request->text;
        $service->updated_at = now();
        $service->save();
        return redirect()->route("services.index");
    }
}
