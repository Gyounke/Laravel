<?php

namespace App\Http\Controllers;

use App\Models\Skill;
use Illuminate\Http\Request;

class SkillController extends Controller
{
    public function index(){
        $skill = Skill::all();
        return view('tables.skilltable', compact('skill'));
    }

    public function destroy($id){
        $skill = Skill::find($id);
        $skill->delete();
        return redirect()->back();
    }

    public function edit($lid){
        $skill = Skill::find($lid);
        return view('edit.skilledit', compact('skill'));
    }

    public function update($id, Request $request) {
        $skill = Skill::find($id);
        $skill->percentage = $request->percentage;
        $skill->skill = $request->skill;
        $skill->updated_at = now();
        $skill->save();
        return redirect()->route("skills.index");
    }
}
