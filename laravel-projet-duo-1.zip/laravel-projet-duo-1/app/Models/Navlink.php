<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Navlink extends Model
{
    use HasFactory;
    
    protected $table = "navlinks";
    public $timestamps = false;

}
