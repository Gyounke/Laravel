<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AboutSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('abouts')->insert([
            "scores"=>"750+",
            "text"=>"Projects Finished",
        ]);
        DB::table('abouts')->insert([
            "scores"=>"340+",
            "text"=>"Happy Clients",
        ]);
        DB::table('abouts')->insert([
            "scores"=>"128+",
            "text"=>"Awards",
        ]);
    }
}
