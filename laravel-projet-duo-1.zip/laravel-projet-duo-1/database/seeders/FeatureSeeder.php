<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FeatureSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('features')->insert([
            "number" => 01, 
            "numberbg" => "first-number",
            "icon" => "first-feature", 
            "title" => "Reach Out",
            "text" => "This HTML5 template is based on Bootstrap 5 CSS. You are free to customize anything.",
        ]);
        DB::table('features')->insert([
            "number" => 02, 
            "numberbg" => "second-number",
            "icon" => "second-feature", 
            "title" => "Develop a Strategy",
            "text" => "Lorem ipsum dolor sit ameter consectetur adipiscing li elit sed do eiusmod.",
        ]);
        DB::table('features')->insert([
            "number" => 03, 
            "numberbg" => "third-number",
            "icon" => "first-feature", 
            "title" => "Implementation",
            "text" => "If this template is useful for your website, please consider to support us a little.",
        ]);
        DB::table('features')->insert([
            "number" => 04, 
            "numberbg" => "fourth-number",
            "icon" => "second-feature", 
            "title" => "Analyze the result",
            "text" => "Below circular progress bar animation supports those CSS values 10, 20, 30, till 100.",
        ]);
    }
}
