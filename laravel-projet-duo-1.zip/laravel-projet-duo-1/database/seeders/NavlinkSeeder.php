<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class NavlinkSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('navlinks')->insert([
            "content" => "Home", 
            "link" => "#top",
            "created_at" => now()
        ]);

        DB::table('navlinks')->insert([
            "content" => "Features", 
            "link" => "#features",
            "created_at" => now()
        ]);

        DB::table('navlinks')->insert([
            "content" => "About Us", 
            "link" => "#about",
            "created_at" => now()
        ]);

        DB::table('navlinks')->insert([
            "content" => "Services", 
            "link" => "#services",
            "created_at" => now()
        ]);

        DB::table('navlinks')->insert([
            "content" => "Portfolio", 
            "link" => "#portfolio",
            "created_at" => now()
        ]);

        DB::table('navlinks')->insert([
            "content" => "Contact Us", 
            "link" => "#contact",
            "created_at" => now()
        ]);
    }
}
