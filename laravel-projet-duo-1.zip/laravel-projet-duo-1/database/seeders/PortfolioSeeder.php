<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PortfolioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('portfolios')->insert([
            "image" => "images/portfolio-01.jpg", 
            "title" => 101,
            "text" => "Marketing"
        ]);
        DB::table('portfolios')->insert([
            "image" => "images/portfolio-02.jpg", 
            "title" => 102,
            "text" => "Branding"
        ]);
        DB::table('portfolios')->insert([
            "image" => "images/portfolio-03.jpg", 
            "title" => 103,
            "text" => "Consulting"
        ]);
        DB::table('portfolios')->insert([
            "image" => "images/portfolio-04.jpg", 
            "title" => 104,
            "text" => "Artwork"
        ]);
        DB::table('portfolios')->insert([
            "image" => "images/portfolio-05.jpg", 
            "title" => 105,
            "text" => "Branding"
        ]);
        DB::table('portfolios')->insert([
            "image" => "images/portfolio-06.jpg", 
            "title" => 106,
            "text" => "Artwork"
        ]);
        DB::table('portfolios')->insert([
            "image" => "images/portfolio-02.jpg", 
            "title" => 107,
            "text" => "Creative"
        ]);
        DB::table('portfolios')->insert([
            "image" => "images/portfolio-01.jpg", 
            "title" => 108,
            "text" => "Consulting"
        ]);
    }
}
