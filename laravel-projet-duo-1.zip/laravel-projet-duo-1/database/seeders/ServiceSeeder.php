<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ServiceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('services')->insert([
            "iconpath" => "images/service-icon-01.png", 
            "title" => "Similar Websites",
            "text" => "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dormque laudantium.",
        ]);
        DB::table('services')->insert([
            "iconpath" => "images/service-icon-02.png", 
            "title" => "Website Trends",
            "text" => "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dormque laudantium.",
        ]);
        DB::table('services')->insert([
            "iconpath" => "images/service-icon-03.png", 
            "title" => "Traffice Analysis",
            "text" => "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dormque laudantium.",
        ]);
        DB::table('services')->insert([
            "iconpath" => "images/service-icon-03.png", 
            "title" => "Optimizing Keywords",
            "text" => "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dormque laudantium.",
        ]);
        DB::table('services')->insert([
            "iconpath" => "images/service-icon-02.png", 
            "title" => "Page Optimizations",
            "text" => "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dormque laudantium.",
        ]);
        DB::table('services')->insert([
            "iconpath" => "images/service-icon-01.png", 
            "title" => "Deep URL Analysis",
            "text" => "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dormque laudantium.",
        ]);
    }
}
