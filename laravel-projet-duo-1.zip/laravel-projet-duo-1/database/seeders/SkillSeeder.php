<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SkillSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('skills')->insert([
            "percentage" => 80,
            "skill" => "HTML/CSS/JS",
        ]);
        DB::table('skills')->insert([
            "percentage" => 60,
            "skill" => "WORDPRESS",
        ]);
        DB::table('skills')->insert([
            "percentage" => 90,
            "skill" => "MARKETING",
        ]);
        DB::table('skills')->insert([
            "percentage" => 70,
            "skill" => "PHOTOSHOP",
        ]);
    }
}
