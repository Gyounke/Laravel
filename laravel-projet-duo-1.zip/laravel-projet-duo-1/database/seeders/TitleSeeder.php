<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TitleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('titles')->insert([
            "s_title" => "ABOUT US",
            "em" => " Marketing ",
            "span" => " With Us ",
            "title_1" => "Top",
            "title_2" => "Agency & Consult Your Website",
            "title_3" => "",
        ]);
        DB::table('titles')->insert([
            "s_title" => "OUR SERVICES",
            "em" => " Clients ",
            "span" =>  "Offer ",
            "title_1" => "Discover What We Do &",
            "title_2" => "To Our",
            "title_3" => "",
        ]);
        DB::table('titles')->insert([
            "s_title" => "OUR PORTFOLIO",
            "em" => " Projects ",
            "span" => " Showcases ",
            "title_1" => "Discover Our Recent",
            "title_2" => "And",
            "title_3" => "",
        ]);
        DB::table('titles')->insert([
            "s_title" => "CONTACT US",
            "em" => " Touch ",
            "span" => " Get ",
            "title_1" => "Fill Out The Form Below To",
            "title_2" => "In",
            "title_3" => "With Us",
        ]);
    }
}
