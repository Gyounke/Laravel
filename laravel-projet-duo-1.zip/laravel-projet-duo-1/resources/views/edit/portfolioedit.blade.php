<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>EDIT</title>
</head>
<body>
    <h1>Portfolio Edit</h1>
    <form action="/portfolioupdate/{{ $portfolio->id }}" method="post">
        @csrf
        <label for="">Image :</label>
        <input type="text" name="image" value="{{ $portfolio->image }}">
        <label for="">Title :</label>
        <input type="text" name="title" value="{{ $portfolio->title }}">
        <label for="">Text :</label>
        <input type="text" name="text" value="{{ $portfolio->text }}">
        <button type="submit">Update</button>
    </form>
</body>
</html>