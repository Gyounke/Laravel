<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>EDIT</title>
</head>
<body>
    <h1>Title Edit</h1>
    <form action="/titleupdate/{{ $title->id }}" method="post">
        @csrf
        <label for="">S_Title :</label>
        <input type="text" name="s_title" value="{{ $title->s_title }}">
        <label for="">Em :</label>
        <input type="text" name="em" value="{{ $title->em }}">
        <label for="">Span :</label>
        <input type="text" name="span" value="{{ $title->span }}">
        <label for="">Title_1 :</label>
        <input type="text" name="title_1" value="{{ $title->title_1 }}">
        <label for="">Title_2 :</label>
        <input type="text" name="title_2" value="{{ $title->title_2 }}">
        <label for="">Title_3 :</label>
        <input type="text" name="title_3" value="{{ $title->title_3 }}">
        <button type="submit">Update</button>
    </form>
</body>
</html>