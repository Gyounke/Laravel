<div id="about" class="about-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="left-image wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">            
            <img src={{ asset("images/about-left-image.png") }} alt="">
          </div>
        </div>
        <div class="col-lg-6 align-self-center wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
          <div class="section-heading">
            <h6>{{ $title[0]->s_title }}</h6>
            <h2>{{ $title[0]->title_1 }} <em>{{ $title[0]->em }}</em> {{ $title[0]->title_2 }} <span>{{ $title[0]->span }}</span></h2>
          </div>
          <div class="row">
          @foreach ($about as $item)
            <div class="col-lg-4 col-sm-4">
              <div class="about-item">
                <h4>{{ $item->scores}}</h4>
                <h6>{{$item->text}}</h6>
              </div>
            </div>
            
          @endforeach
          
          </div>
          <p><a rel="nofollow" href="https://templatemo.com/tm-563-seo-dream" target="_parent">SEO Dream</a> is free digital marketing CSS template provided by TemplateMo website. You are allowed to use this template for your business websites. Please DO NOT redistribute this template ZIP file on any Free CSS collection websites. You may contact us for more information. Thank you.</p>
          <div class="main-green-button"><a href="#">Discover company</a></div>
        </div>
      </div>
    </div>
  </div>