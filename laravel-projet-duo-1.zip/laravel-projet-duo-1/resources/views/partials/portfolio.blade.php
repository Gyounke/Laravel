<div id="portfolio" class="our-portfolio section">
    <div class="container">
      <div class="row">
        <div class="col-lg-5">
          <div class="section-heading wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
            <h6>{{ $title[2]->s_title }}</h6>
            <h2>{{ $title[2]->title_1 }} <em>{{ $title[2]->em }}</em> {{ $title[2]->title_2 }} <span>{{ $title[2]->span }}</span></h2>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid wow fadeIn" data-wow-duration="1s" data-wow-delay="0.7s">
      <div class="row">
        <div class="col-lg-12">
          <div class="loop owl-carousel">
            

            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="{{ $portfolio[0]->image }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project {{ $portfolio[0]->title }}</h4></a>
                      <span>{{ $portfolio[0]->text }}</span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="{{ $portfolio[1] ->image }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project {{ $portfolio[1]->title }}</h4></a>
                      <span>{{ $portfolio[1]->text }}</span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
            </div> 
            
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="{{ $portfolio[2]->image }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project {{ $portfolio[2]->title }}</h4></a>
                      <span>{{ $portfolio[2]->text }}</span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="{{ $portfolio[3] ->image }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project {{ $portfolio[3]->title }}</h4></a>
                      <span>{{ $portfolio[3]->text }}</span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
            </div>

            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="{{ $portfolio[4]->image }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project {{ $portfolio[4]->title }}</h4></a>
                      <span>{{ $portfolio[4]->text }}</span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="{{ $portfolio[5]->image }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project {{ $portfolio[5]->title }}</h4></a>
                      <span>{{ $portfolio[5]->text }}</span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
            </div> 
            
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="{{ $portfolio[6]->image }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project {{ $portfolio[6]->title }}</h4></a>
                      <span>{{ $portfolio[6]->text }}</span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="{{ $portfolio[7] ->image }}" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project {{ $portfolio[7]->title }}</h4></a>
                      <span>{{ $portfolio[7]->text }}</span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
            </div>




          </div>
        </div>
      </div>
    </div>
  </div>