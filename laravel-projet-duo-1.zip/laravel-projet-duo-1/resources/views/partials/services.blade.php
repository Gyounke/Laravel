<div id="services" class="our-services section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading wow bounceIn" data-wow-duration="1s" data-wow-delay="0.2s">
            <h6>{{ $title[1]->s_title }}</h6>
            <h2>{{ $title[1]->title_1 }} <span>{{ $title[1]->span }}</span> {{ $title[1]->title_2 }} <em>{{ $title[1]->em }}</em></h2>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
        <div class="row">
        @php
            shuffle($arrayshuffle_2);
        @endphp
        @foreach ($arrayshuffle_2 as $item)
        <div class="col-lg-4">
            <div class="service-item wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.3s">
                
              <div class="row">
                <div class="col-lg-4">
                  <div class="icon">
                    <img src="{{ $item->iconpath }}" alt="">
                  </div>
                </div>
                <div class="col-lg-8">
                  <div class="right-content">
                    <h4>{{ $item->title }}</h4>
                    <p>{{ $item->text }}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        @endforeach
        
      </div>
        
    </div>
  </div>