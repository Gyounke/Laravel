{{-- @extends('pages.backoffice')


@section('discovertable')
    
<h5 class="fw-bold mt-5"><strong><u>DISCOVER</u></strong></h5>
<div class="container">
<table class="table">
    <thead>
        <tr>
            <th scope="col">scores</th>
            <th scope="col">text</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($discover as $item)
            <tr>
                <th scope="row">{{ $item->scores }}</th>
                <td>{{ $item->text }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
</div>
@endsection --}}