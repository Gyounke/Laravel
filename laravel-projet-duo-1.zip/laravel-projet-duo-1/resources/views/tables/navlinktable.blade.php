@extends('backoffice')


@section('navlinktable')
    
<div class="container">
<h5 class="fw-bold mt-5"><strong><u>NAVLINK</u></strong></h5>
<table class="table">
    <thead>
        <tr>
            <th scope="col">content</th>
            <th scope="col">link</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($navlink as $item)
            <tr>
                <th scope="row">{{ $item->content }}</th>
                <td>{{ $item->link }}</td>
                <td>
                    <form action="{{ route("navlinks.destroy", $item->id) }}" method="post">
                        @csrf
                        <button class="btn btn-danger" type="submit">delete</button>
                    </form>
                </td>
                
                <td>
                    <a href="{{ route("navlinks.edit", $item->id) }}">edit</a>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
</div>
@endsection