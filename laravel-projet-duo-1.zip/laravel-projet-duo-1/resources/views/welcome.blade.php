@extends('layouts.app')

@section('content')
      <!-- ***** Preloader Start ***** -->
  {{-- <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div> --}}
  <!-- ***** Preloader End ***** -->

  @include('partials.header')

  @include('partials.banner')

  @include('partials.features')

  @include('partials.about')

  @include('partials.services')

  @include('partials.portfolio')

  @include('partials.contact')

  @include('partials.footer')
@endsection