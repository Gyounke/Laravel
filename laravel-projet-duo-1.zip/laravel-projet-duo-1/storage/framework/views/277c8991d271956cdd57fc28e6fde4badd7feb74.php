
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">

    <title>SEO Dream - Creative SEO HTML5 Template by TemplateMo</title>

    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset("css/bootstrap.min.css")); ?>" rel="stylesheet">


    <!-- Additional CSS Files -->
    
    <link rel="stylesheet" href="<?php echo e(asset("css/fontawesome.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/templatemo-seo-dream.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/animated.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/owl.css")); ?>">
    
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
<!--

TemplateMo 563 SEO Dream

https://templatemo.com/tm-563-seo-dream

-->

</head>

<body>

  <?php echo $__env->yieldContent('content'); ?>

  <?php echo $__env->yieldContent('backoffice'); ?>

  <!-- Scripts -->
  
  <script src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>

  <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>

  <script src="<?php echo e(asset('js/owl-carousel.js')); ?>"></script>
  
  <script src="<?php echo e(asset('js/animation.js')); ?>"></script>
  
  <script src="<?php echo e(asset('js/imagesloaded.js')); ?>"></script>
  
  <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

  <script src="<?php echo e(asset('js/app.js')); ?>"></script>

</body>
</html><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/layouts/app.blade.php ENDPATH**/ ?>