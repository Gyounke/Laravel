<div id="services" class="our-services section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading wow bounceIn" data-wow-duration="1s" data-wow-delay="0.2s">
            <h6><?php echo e($title[1]->s_title); ?></h6>
            <h2><?php echo e($title[1]->title_1); ?> <span><?php echo e($title[1]->span); ?></span> <?php echo e($title[1]->title_2); ?> <em><?php echo e($title[1]->em); ?></em></h2>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
        <div class="row">
        <?php
            shuffle($arrayshuffle_2);
        ?>
        <?php $__currentLoopData = $arrayshuffle_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4">
            <div class="service-item wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.3s">
                
              <div class="row">
                <div class="col-lg-4">
                  <div class="icon">
                    <img src="<?php echo e($item->iconpath); ?>" alt="">
                  </div>
                </div>
                <div class="col-lg-8">
                  <div class="right-content">
                    <h4><?php echo e($item->title); ?></h4>
                    <p><?php echo e($item->text); ?></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </div>
        
    </div>
  </div><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/partials/services.blade.php ENDPATH**/ ?>