


<?php $__env->startSection('servicetable'); ?>
    
<div class="container">
<h5 class="fw-bold mt-5"><strong><u>SERVICE</u></strong></h5>
<table class="table">
    <thead>
        <tr>
            <th scope="col">iconpath</th>
            <th scope="col">title</th>
            <th scope="col">text</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($item->iconpath); ?></th>
                <td><?php echo e($item->title); ?></td>
                <td><?php echo e($item->text); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/tables/servicetable.blade.php ENDPATH**/ ?>