


<?php $__env->startSection('skilltable'); ?>
    
<div class="container">
<h5 class="fw-bold mt-5"><strong><u>SKILL</u></strong></h5>
<table class="table">
    <thead>
        <tr>
            <th scope="col">percentage</th>
            <th scope="col">skill</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($item->percentage); ?></th>
                <td><?php echo e($item->skill); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/tables/skilltable.blade.php ENDPATH**/ ?>