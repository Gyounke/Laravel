<div id="portfolio" class="our-portfolio section">
    <div class="container">
      <div class="row">
        <div class="col-lg-5">
          <div class="section-heading wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
            <h6><?php echo e($title[2]->s_title); ?></h6>
            <h2><?php echo e($title[2]->title_1); ?> <em><?php echo e($title[2]->em); ?></em> <?php echo e($title[2]->title_2); ?> <span><?php echo e($title[2]->span); ?></span></h2>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid wow fadeIn" data-wow-duration="1s" data-wow-delay="0.7s">
      <div class="row">
        <div class="col-lg-12">
          <div class="loop owl-carousel">
            

            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="<?php echo e($portfolio[0]->image); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project <?php echo e($portfolio[0]->title); ?></h4></a>
                      <span><?php echo e($portfolio[0]->text); ?></span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="<?php echo e($portfolio[1] ->image); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project <?php echo e($portfolio[1]->title); ?></h4></a>
                      <span><?php echo e($portfolio[1]->text); ?></span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
            </div> 
            
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="<?php echo e($portfolio[2]->image); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project <?php echo e($portfolio[2]->title); ?></h4></a>
                      <span><?php echo e($portfolio[2]->text); ?></span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="<?php echo e($portfolio[3] ->image); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project <?php echo e($portfolio[3]->title); ?></h4></a>
                      <span><?php echo e($portfolio[3]->text); ?></span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
            </div>

            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="<?php echo e($portfolio[4]->image); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project <?php echo e($portfolio[4]->title); ?></h4></a>
                      <span><?php echo e($portfolio[4]->text); ?></span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="<?php echo e($portfolio[5] ->image); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project <?php echo e($portfolio[5]->title); ?></h4></a>
                      <span><?php echo e($portfolio[5]->text); ?></span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
            </div> 
            
            <div class="item">
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="<?php echo e($portfolio[6]->image); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project <?php echo e($portfolio[6]->title); ?></h4></a>
                      <span><?php echo e($portfolio[6]->text); ?></span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
              <div class="portfolio-item">
                <div class="thumb">
                    <img src="<?php echo e($portfolio[7] ->image); ?>" alt="">
                  <div class="hover-content">
                    <div class="inner-content">
                      <a href="#"><h4>Awesome Project <?php echo e($portfolio[7]->title); ?></h4></a>
                      <span><?php echo e($portfolio[7]->text); ?></span>
                    </div>
                  </div>
                </div>
                <br>
              </div>
            </div>




          </div>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/partials/portfolio.blade.php ENDPATH**/ ?>