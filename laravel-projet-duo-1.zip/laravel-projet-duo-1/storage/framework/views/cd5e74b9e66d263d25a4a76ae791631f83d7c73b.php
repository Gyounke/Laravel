<div id="features" class="features section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="features-content">
            <div class="row">
              <?php
                  shuffle($arrayshuffle_1);
              ?>
              <?php $__currentLoopData = $arrayshuffle_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              
              <div class="col-lg-3">
                <div class="features-item <?php echo e($item->icon); ?> wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
                  <div class="<?php echo e($item->numberbg); ?> number">
                    <h6><?php echo e($item->number); ?></h6>
                  </div>
                  <div class="icon"></div>
                  <h4><?php echo e($item->title); ?></h4>
                  <div class="line-dec"></div>
                  <p><?php echo e($item->text); ?></p>
                </div>
              </div>
              

              
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>


        <div class="col-lg-12">
          <div class="skills-content">
            <div class="row">
              <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-3">
                <div class="skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                  <div class="progress" data-percentage="<?php echo e($item->percentage); ?>">
                    <span class="progress-left">
                      <span class="progress-bar"></span>
                    </span>
                    <span class="progress-right">
                      <span class="progress-bar"></span>
                    </span>
                    <div class="progress-value">
                      <div>
                        <?php echo e($item->percentage); ?>%<br>
                        <span><?php echo e($item->skill); ?></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            
            </div>
          </div>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/partials/features.blade.php ENDPATH**/ ?>