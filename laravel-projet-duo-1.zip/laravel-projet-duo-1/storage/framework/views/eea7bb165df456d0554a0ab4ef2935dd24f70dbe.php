


<?php $__env->startSection('abouttable'); ?>
    
<div class="container">
    <h5 class="fw-bold mt-5"><strong><u>ABOUT</u></strong></h5>
<table class="table">
    <thead>
        <tr>
            <th scope="col">scores</th>
            <th scope="col">text</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($item->scores); ?></th>
                <td><?php echo e($item->text); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-projet-duo-1\resources\views/tables/abouttable.blade.php ENDPATH**/ ?>